type ToDoListType = {
  input: string | null;
  key: string | null;
  completed: boolean;
};

export default ToDoListType;
