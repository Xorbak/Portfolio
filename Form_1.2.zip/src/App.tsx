import "./App.css";
import React, { useEffect } from "react";
import GrabInput from "./components/GrabInput";
import { CompletedTodoList } from "./components/TodoLists/CompletedTodoList";
import { useState } from "react";
import ToDoListType from "./Ts/Model";
import { Box } from "@mui/material";
import { PendingTodoList } from "./components/TodoLists/PendingTodoList";
import { ToDo } from "./Screens/ToDo";
import { RegistrationForm } from "./Screens/RegistrationForm";
import { Route, Routes } from "react-router-dom";
import { Home } from "./Screens/Home";
import { Navbar } from "./components/Navbar";

function App() {
  return (
    <Box>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/To-do" element={<ToDo />} />
        <Route path="/Registration" element={<RegistrationForm />} />
      </Routes>
    </Box>
  );
}

export default App;
