import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import React from "react";
import ReplayIcon from "@mui/icons-material/Replay";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";

export const CompletedTodoList = (props: any) => {
  return (
    <Box style={{ width: "100%" }}>
      {props.completedToDo.map((i: any) => (
        <Box sx={styles.toDoItem}>
          <MenuItem key={i.key} sx={styles.ToDoInput}>
            {i.input}
          </MenuItem>
          <Box>
            <ReplayIcon
              sx={styles.ToDoControl}
              fontSize="small"
              onClick={() => props.addtoDo(i.input, i.key)}
            />
            <DeleteOutlineIcon
              sx={styles.ToDoControl}
              onClick={() => props.remove(i.key)}
              fontSize="small"
            />
          </Box>
        </Box>
      ))}
    </Box>
  );
};
const styles = {
  toDoItem: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    alignContent: "center",
    paddingRight: "2%",
    fontSize: "15px",
    border: "1px solid #d7d7d7",
    boxShadow: "#0d7377",
    backgroundColor: "#21c3b5",
    borderRadius: "5px",
    paddingLeft: "5px",
    marginBottom: "2%",
  },
  ToDoInput: {
    listStyleType: "none",
    cursor: "pointer",
    "&:hover": {
      cursor: "pointer",
    },
  },
  ToDoControl: {
    "&:hover": { cursor: "pointer", backgroundColor: "#30d4da" },
  },
};
