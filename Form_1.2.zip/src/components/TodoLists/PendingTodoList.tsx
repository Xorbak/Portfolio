import CheckIcon from "@mui/icons-material/Check";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import React from "react";
export const PendingTodoList = (props: any) => {
  return (
    <Box style={{ width: "100%" }}>
      {props.toDo.map((i: any) => (
        <Box sx={styles.toDoItem} key={i.key}>
          <MenuItem key={i.key} sx={styles.ToDoInput}>
            {i.input}
          </MenuItem>

          <Box>
            <CheckIcon
              sx={styles.ToDoControl}
              fontSize="small"
              onClick={() => props.completed(i.key, i.input)}
            />
            <DeleteOutlineIcon
              sx={styles.ToDoControl}
              onClick={() => props.remove(i.key)}
              fontSize="small"
            />
          </Box>
        </Box>
      ))}
    </Box>
  );
};

const styles = {
  toDoItem: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    alignContent: "center",
    paddingRight: "2%",
    fontSize: "15px",
    border: "1px solid #d7d7d7",
    boxShadow: "#0d7377",
    backgroundColor: "#21c3b5",
    borderRadius: "5px",
    paddingLeft: "5px",
    marginBottom: "2%",
  },
  ToDoInput: {
    listStyleType: "none",
    cursor: "pointer",
    "&:hover": {
      cursor: "pointer",
    },
  },
  ToDoControl: {
    "&:hover": { cursor: "pointer", backgroundColor: "#30d4da" },
  },
};
