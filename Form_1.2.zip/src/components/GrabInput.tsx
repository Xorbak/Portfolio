import Button from "@mui/material/Button";
import Input from "@mui/material/Input";
import InputAdornment from "@mui/material/InputAdornment";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { Formik, Form, Field } from "formik";
import React from "react";
import toDoSchema from "./TodoLists/Validation";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";

//@ts-ignore
const MyInput = ({ field, form, ...props }) => {
  return (
    <TextField
      variant="outlined"
      autoComplete="off"
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <Button style={{ color: "black" }} type="submit">
              <AddCircleOutlineIcon />
            </Button>
          </InputAdornment>
        ),
      }}
      {...field}
      {...props}
    />
  );
};
interface Props {
  addToDo(item: string, id: string): void;
}
interface FormikFieldTypes {
  inputField: string;
}
const GrabInput = ({ addToDo }: Props) => {
  return (
    <Formik<FormikFieldTypes>
      initialValues={{ inputField: "" }}
      onSubmit={(values, { resetForm }) => {
        addToDo(values.inputField, "1");
        resetForm();
      }}
      validationSchema={toDoSchema}
    >
      {({ errors }) => {
        return (
          <Form style={{ width: "100%", paddingTop: "3%" }}>
            <Field
              name="inputField"
              component={MyInput}
              style={{ width: "100%" }}
            />
            <Typography
              style={{ color: "red", display: "flex", fontSize: "small" }}
            >
              {errors.inputField}
            </Typography>
          </Form>
        );
      }}
    </Formik>
  );
};

export default GrabInput;
