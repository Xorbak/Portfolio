import { Visibility, VisibilityOff } from "@mui/icons-material";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { Field, Form, Formik } from "formik";
import React, { useState } from "react";
import idschema from "./validation/idschema";

interface Props {
  addinfo(userName: String, password: String): void;
}
interface IDinterface {
  userName: string;
  password: string;
  confirmPassword: string;
}

//@ts-ignore
const UserName = ({ field, form, ...props }) => {
  return (
    <TextField autoComplete="off" label="Username" {...field} {...props} />
  );
}; //@ts-ignore
const Password = ({ field, form, ...props }) => {
  //set states to toggle visibility of password field
  const [showPassword, setShowPassword] = useState("password");
  const [passwordIcon, setPasswordIcon] = useState(<Visibility />);
  const togglePassword = () => {
    if (showPassword == "password") {
      setShowPassword("text");
      setPasswordIcon(<VisibilityOff />);
    } else {
      setShowPassword("password");
      setPasswordIcon(<Visibility />);
    }
  };
  return (
    <TextField
      type={showPassword}
      autoComplete="off"
      autoCapitalize="on"
      label="Password"
      {...field}
      {...props}
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <IconButton onClick={togglePassword}>{passwordIcon}</IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
}; //@ts-ignore
const ConfirmPassword = ({ field, form, ...props }) => {
  const [showPassword, setShowPassword] = useState("password");
  const [passwordIcon, setPasswordIcon] = useState(<Visibility />);
  const togglePassword = () => {
    if (showPassword == "password") {
      setShowPassword("text");
      setPasswordIcon(<VisibilityOff />);
    } else {
      setShowPassword("password");
      setPasswordIcon(<Visibility />);
    }
  };
  return (
    <TextField
      type={showPassword}
      autoComplete="off"
      autoCapitalize="on"
      label="Confirm Password"
      {...field}
      {...props}
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <IconButton onClick={togglePassword}>{passwordIcon}</IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
};

export const UsernamePassword = ({ addinfo }: Props, touched: any) => {
  return (
    <Formik<IDinterface>
      initialValues={{
        userName: "",
        password: "",
        confirmPassword: "",
      }}
      onSubmit={(values, { resetForm }) => {
        addinfo(values.password, values.userName);

        resetForm();
      }}
      validationSchema={idschema}
    >
      {({ errors, touched }) => {
        return (
          <Form>
            <Box sx={styles.formContainer}>
              <Field name="userName" component={UserName} />
              {touched.userName && errors.userName && (
                <Typography sx={styles.errorMessage}>
                  {errors.userName}
                </Typography>
              )}

              <Field name="password" component={Password} />
              {touched.password && errors.password && (
                <Typography sx={styles.errorMessage}>
                  {errors.password}
                </Typography>
              )}

              <Field name="confirmPassword" component={ConfirmPassword} />
              {touched.confirmPassword && errors.confirmPassword && (
                <Typography sx={styles.errorMessage}>
                  {errors.confirmPassword}
                </Typography>
              )}

              <Button type="submit"> Submit</Button>
            </Box>
          </Form>
        );
      }}
    </Formik>
  );
};
const styles = {
  formContainer: {
    display: "grid",
    gridTemplateColumns: "1fr",
    justifyContent: "space-around",
    gridAutoRows: "minmax(2vh, auto)",
    gap: "1%",
    backgroundColor: "#2b2e4a",
    height: "260px",
    width: "30vw",
    borderRadius: "5px",
    padding: "2%",
    paddingTop: "4%",
    "@media (max-width:768px)": {
      height: "300px",
      width: "50vw",
      padding: "1%",
      paddingTop: "5%",
    },
    "@media (max-width:320px)": {
      width: "90vw",
      padding: "1%",
      paddingTop: "5%",
    },
  },
  errorMessage: {
    color: "red",
    display: "flex",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    alignSelf: "flex-start",
    fontSize: "small",
  },
};
