import { Button, TextField, Typography } from "@mui/material";
import Box from "@mui/material/Box";
import { Field, Form, Formik } from "formik";
import React from "react";
import contactinfoVal from "./validation/contactinfoVal";

interface ContactinfoInterface {
  email: string;
  phoneNumber: number;
  postalAddress: string;
}
interface addContact {
  addContact(email: string, phoneNumber: number, postalAddress: string): void;
}
//@ts-ignore
const emailInput = ({ field, form, ...props }) => {
  return (
    <TextField
      autoComplete="off"
      label="Email"
      placeholder="Email"
      {...field}
      {...props}
    />
  );
}; //@ts-ignore
const phoneNumberInput = ({ field, form, ...props }) => {
  return (
    <TextField
      type={"number"}
      autoComplete="off"
      label="Phone number"
      placeholder="Phone number"
      {...field}
      {...props}
    />
  );
}; //@ts-ignore
const postalAdress = ({ field, form, ...props }) => {
  return (
    <TextField
      autoComplete="off"
      label="Postal address"
      placeholder="Postal address"
      {...field}
      {...props}
    />
  );
};
export const ContactInfo = ({ addContact }: addContact, touched: any) => {
  return (
    <Formik<ContactinfoInterface>
      initialValues={{ email: "", phoneNumber: 0, postalAddress: "" }}
      onSubmit={(values) => {
        addContact(values.email, values.phoneNumber, values.postalAddress);
        console.log(values.email, values.phoneNumber, values.postalAddress);
      }}
      validationSchema={contactinfoVal}
    >
      {({ errors, touched }) => {
        return (
          <Form>
            <Box sx={styles.formContainer}>
              <Field name="email" component={emailInput} />
              {errors.email && touched.email && (
                <Typography sx={styles.errorMessage}>{errors.email}</Typography>
              )}
              <Field name="phoneNumber" component={phoneNumberInput} />
              {errors.phoneNumber && touched.phoneNumber && (
                <Typography sx={styles.errorMessage}>
                  {errors.phoneNumber}
                </Typography>
              )}
              <Field name="postalAddress" component={postalAdress} />
              {errors.postalAddress && touched.postalAddress && (
                <Typography sx={styles.errorMessage}>
                  {errors.postalAddress}
                </Typography>
              )}
              <Button type="submit">Submit</Button>
            </Box>
          </Form>
        );
      }}
    </Formik>
  );
};
const styles = {
  formContainer: {
    display: "grid",
    gridTemplateColumns: "1fr",
    justifyContent: "space-around",
    gridAutoRows: "minmax(2vh, auto)",
    gap: "1%",
    backgroundColor: "#2b2e4a",
    height: "260px",
    width: "30vw",
    borderRadius: "5px",
    padding: "2%",
    paddingTop: "4%",
    "@media (max-width:768px)": {
      height: "300px",
      width: "50vw",
      padding: "1%",
      paddingTop: "5%",
    },
    "@media (max-width:320px)": {
      width: "90vw",
      padding: "1%",
      paddingTop: "5%",
    },
  },
  errorMessage: {
    color: "red",
    display: "flex",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    alignSelf: "flex-start",
    fontSize: "small",
  },
};
