import {
  Button,
  InputLabel,
  MenuItem,
  Select,
  Typography,
} from "@mui/material";
import { FormControlLabel } from "@mui/material";
import { FormLabel } from "@mui/material";
import { Radio } from "@mui/material";
import { RadioGroup } from "@mui/material";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Field, Form, Formik } from "formik";
import React from "react";
import demographicSchema from "./validation/demographicsSchema";
interface demographic {
  firstname: string;
  lastname: string;
  age: number;
  married: string;
  highestEducation: string;
}
interface Props {
  addDemographics(
    firstname: string,
    lastname: string,
    age: number,
    married: string,
    highestEducation: string
  ): void;
}

//@ts-ignore
const firstname = ({ field, form, ...props }) => {
  return (
    <TextField autoComplete="off" label="First Name" {...field} {...props} />
  );
};
//@ts-ignore
const lastname = ({ field, form, ...props }) => {
  return (
    <TextField autoComplete="off" label="Last Name" {...field} {...props} />
  );
}; //@ts-ignore
const age = ({ field, form, ...props }) => {
  return (
    <TextField
      type={"number"}
      autoComplete="off"
      label="age"
      {...field}
      {...props}
    />
  );
}; //@ts-ignore
const married = ({ field, form, ...props }) => {
  return (
    <Box>
      <FormLabel>Mariage Status</FormLabel>
      <RadioGroup
        row
        sx={{ color: "rgba(0, 0, 0, 0.6)" }}
        {...field}
        {...props}
      >
        <FormControlLabel
          value="Unmarried"
          control={<Radio size="small" />}
          label="Unmarried"
        />
        <FormControlLabel
          value="Married"
          control={<Radio size="small" />}
          label="Married"
        />
        <FormControlLabel
          value="Divorced"
          control={<Radio size="small" />}
          label="Divorced"
        />
        <FormControlLabel
          value="Widowed"
          control={<Radio size="small" />}
          label="Widowed"
        />
      </RadioGroup>
    </Box>
  );
}; //@ts-ignored
const highestEducation = ({ field, form, ...props }) => {
  const [education, setEducation] = React.useState("");
  //save the option you choose as the value
  const handleChange = (event: any) => {
    setEducation(event.target.value as string);
  };
  return (
    <Box>
      <InputLabel id="demo-simple-select-label">Highest Education</InputLabel>
      <Select
        sx={{ width: "100%", color: "rgba(0, 0, 0, 0.6)" }}
        value={education}
        onChange={handleChange}
        label="Highest Education"
        {...field}
        {...props}
      >
        <MenuItem value={"none"}>None</MenuItem>
        <MenuItem value={"Highschool Diploma"}>Highschool Diploma</MenuItem>
        <MenuItem value={"Bachelor's Degree"}>Batcholers Degree</MenuItem>
        <MenuItem value={"Master's Degree"}>Master's Degree</MenuItem>
        <MenuItem value={"Doctoral "}>Doctoral </MenuItem>
        <MenuItem value={"PHD"}>PHD </MenuItem>
        <MenuItem value={"Diploma "}>Diploma </MenuItem>{" "}
        <MenuItem value={"Dumb AF"}>My mom says I'm smart </MenuItem>
      </Select>
    </Box>
  );
};

export const Demographics = ({ addDemographics }: Props, touched: any) => {
  return (
    <Formik<demographic>
      initialValues={{
        firstname: "",
        lastname: "",
        age: 0,
        married: "",
        highestEducation: "",
      }}
      onSubmit={(values) => {
        addDemographics(
          values.firstname,
          values.lastname,
          values.age,
          values.married,
          values.highestEducation
        );
        console.log(values);
      }}
      validationSchema={demographicSchema}
    >
      {({ errors, touched }) => {
        return (
          <Form>
            <Box sx={styles.formContainer}>
              <Box sx={styles.firstlastName}>
                <Box>
                  <Field name="firstname" component={firstname} />
                  {touched.firstname && errors.firstname && (
                    <Typography sx={styles.errorMessage}>
                      {errors.firstname}
                    </Typography>
                  )}
                </Box>
                <Box>
                  <Field name="lastname" component={lastname} />
                  {touched.lastname && errors.lastname && (
                    <Typography sx={styles.errorMessage}>
                      {errors.lastname}
                    </Typography>
                  )}
                </Box>
              </Box>
              <Box sx={{ width: "100%" }}>
                <Field sx={{ width: "48.5%" }} name="age" component={age} />
                {touched.age && errors.age && (
                  <Typography sx={styles.errorMessage}>{errors.age}</Typography>
                )}
              </Box>

              <Field name="married" component={married} />
              <Field name="highestEducation" component={highestEducation} />
              <Button type="submit">Submit</Button>
            </Box>
          </Form>
        );
      }}
    </Formik>
  );
};
const styles = {
  formContainer: {
    display: "grid",
    gridTemplateColumns: "1fr",
    justifyContent: "space-around",
    gridAutoRows: "minmax(50px, auto)",
    gap: "1%",
    backgroundColor: "#2b2e4a",
    height: "300px",
    width: "40vw",
    borderRadius: "5px",
    padding: "2%",
    paddingTop: "4%",

    "@media (max-width:950px)": {
      height: "400px",
      width: "50vw",
      padding: "1%",
      paddingTop: "5%",
    },
    "@media (max-width:650px)": {
      height: "350px",
      width: "90vw",
      padding: "1%",
      paddingTop: "5%",
    },
    "@media (max-width:487px)": {
      height: "400px",
      width: "90vw",
      padding: "1%",
      paddingTop: "5%",
    },
    "@media (max-width:250px)": {
      height: "500px",
      width: "90vw",
      padding: "1%",
      paddingTop: "5%",
    },
  },
  errorMessage: {
    color: "red",
    display: "flex",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    alignSelf: "flex-start",
    fontSize: "small",
    paddingBottom: "2%",
    marginBottom: "2%",
  },
  firstlastName: {
    display: "grid",
    width: "100%",
    gap: "2%",
    gridTemplateColumns: "1fr 1fr",
    paddingBottom: "5%",
    "@media (max-width:250px)": { gridTemplateColumns: "1fr" },
  },
};
