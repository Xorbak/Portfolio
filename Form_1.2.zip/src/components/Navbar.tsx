import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import AccountCircle from "@mui/icons-material/AccountCircle";
import Switch from "@mui/material/Switch";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormGroup from "@mui/material/FormGroup";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import { Link, NavLink } from "react-router-dom";
import "../App";
import Button from "@mui/material/Button";

export function Navbar() {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const TaskDropDown = (
    <Typography variant="h6" sx={styles.NavbarItem}>
      <Button
        id="basic-button"
        aria-controls={open ? "basic-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        size="large"
        style={{ color: "#0d7377" }}
      >
        Tasks
      </Button>

      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          "aria-labelledby": "basic-button",
        }}
      >
        <NavLink
          to="/To-do"
          style={{
            color: "#0d7377",
            textDecoration: "none",
          }}
        >
          <MenuItem onClick={handleClose}>To-Do</MenuItem>
        </NavLink>
        <NavLink
          to="/Registration"
          style={{ color: "#0d7377", textDecoration: "none" }}
        >
          <MenuItem onClick={handleClose}>Registration form</MenuItem>
        </NavLink>
      </Menu>
    </Typography>
  );
  const HomeButton = (
    <Typography variant="h6" sx={styles.NavbarItem}>
      <Button>
        <NavLink style={{ color: "#0d7377", textDecoration: "none" }} to="/">
          Home
        </NavLink>
      </Button>
    </Typography>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar
        position="static"
        style={{ backgroundColor: "#2b2e4a", color: "#0d7377" }}
      >
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          {HomeButton}
          {TaskDropDown}
        </Toolbar>
      </AppBar>
    </Box>
  );
}

const styles = {
  NavbarItem: {
    padding: "1%",
    textDecoration: "none",
  },
};
