import "../App.css";
import React, { useEffect } from "react";
import GrabInput from "../components/GrabInput";
import { CompletedTodoList } from "../components/TodoLists/CompletedTodoList";
import { useState } from "react";
import ToDoListType from "../Ts/Model";
import { Box } from "@mui/material";
import { PendingTodoList } from "../components/TodoLists/PendingTodoList";

export const ToDo = () => {
  const [toDO, setTodo] = useState<ToDoListType[]>([]);
  const [completedToDO, setCompletedToDO] = useState<ToDoListType[]>([]);

  //Adds Items to the ToDo part
  function addToDo(item: string, id: string) {
    setTodo((currentItem) => {
      const todo = [
        ...currentItem,
        {
          input: item,
          key: toDO.length + item,
          completed: false,
        },
      ];

      return todo;
    });
    // when clicking the return button in the Completed column it sends it back

    setCompletedToDO(completedToDO.filter((completed) => completed.key !== id));
  }
  //Deletes the toDO
  const removeToDO = (id: string) => {
    setTodo(toDO.filter((toDO) => toDO.key !== id));
    setCompletedToDO(completedToDO.filter((completed) => completed.key !== id));
  };
  // Move item from Pending to COmpleted
  const completed = (id: string, input: string) => {
    console.log(id);
    //Adds to Completed
    setCompletedToDO((currentItem) => [
      ...currentItem,
      { input: input, key: id, completed: false },
    ]);
    //removes from Pending
    setTodo(toDO.filter((toDO) => toDO.key !== id));
  };

  //Local Storage

  useEffect(() => {
    console.log("get");
    const pending = localStorage.getItem("pending");
    const completed = localStorage.getItem("completed");
    if (pending) {
      setTodo(JSON.parse(pending));
    }
    if (completed) {
      setCompletedToDO(JSON.parse(completed));
    }
  }, []);

  return (
    <Box sx={styles.App}>
      <Box sx={styles.ToDoContainer}>
        <Box sx={styles.InputContainer}>
          <GrabInput addToDo={addToDo} />
        </Box>

        <Box sx={styles.ToDoBox}>
          <Box style={{ marginBottom: "5%", textDecorationLine: "underline" }}>
            Pending Tasks
          </Box>
          <PendingTodoList
            remove={removeToDO}
            completed={completed}
            toDo={toDO}
          />
        </Box>
        <Box sx={styles.Completed}>
          <Box style={{ marginBottom: "5%", textDecorationLine: "underline" }}>
            Completed Tasks
          </Box>
          <CompletedTodoList
            completedToDo={completedToDO}
            remove={removeToDO}
            completed={completed}
            addtoDo={addToDo}
          />
        </Box>
      </Box>
    </Box>
  );
};

const styles = {
  App: {
    textAlign: "center",
    backgroundColor: "#282c34",
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "calc(10px + 2vmin)",
    color: "white",
  },
  ToDoContainer: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr 1fr 1fr",
    gridTemplateRows: "80px",
    gridAutoRows: "minmax(10px, auto)",
    gap: "5%",
    backgroundColor: "#2b2e4a",
    height: "80vh",
    width: "50vw",
    borderRadius: "5px",
    padding: "1%",
    "@media (max-width:800px)": {
      width: "90vw",
      padding: "1%",
      paddingTop: "5%",
    },
  },
  InputContainer: {
    gridColumnStart: "1",
    gridColumnEnd: "-1",
    display: "flex",
    justifyContent: "center",
    alignContent: "center",
  },
  ToDoBox: {
    gridColumn: "span 2",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    color: "#212121",
    backgroundColor: "#14ffec",
    borderRadius: "5px",
    padding: "2%",
    overflow: "scroll",
    "&::-webkit-scrollbar": {
      display: "none",
      overflow: "scroll",
    },
  },
  Completed: {
    gridColumn: "span 2",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    color: "#212121",
    backgroundColor: "#0d7377",
    borderRadius: "5px",
    padding: "2%",
    overflow: "scroll",
    "&::-webkit-scrollbar": {
      display: "none",
      overflow: "scroll",
    },
  },
};
