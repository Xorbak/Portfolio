import Box from "@mui/material/Box";

import React, { useState } from "react";
import { UsernamePassword } from "../components/MultiPageForm/UsernamePassword";
import { Demographics } from "../components/MultiPageForm/Demographics";
import { ContactInfo } from "../components/MultiPageForm/ContactInfo";
import { MenuItem } from "@mui/material";

export const RegistrationForm = () => {
  interface userInfoTypes {
    username?: string;
    password?: string;
    firstname?: string;
    lastname?: string;
    email?: string;
    phoneNumber?: number;
    postalAddress?: string;
    age?: number;
    married?: boolean;
    highestEducation?: string;
  }
  const [userinfo, setUserinfo] = useState<userInfoTypes | null>(null);
  //Sets username and Password
  function addUserinfo(password: string, username: string) {
    let updateUser: any = "";
    updateUser = {
      username: username,
      password: password,
    };
    console.log("username,", username, " Password,", password);
    //push the data from Identification form to the userinfo state all other forms will be doing the same
    setUserinfo((userinfo) => ({ ...userinfo, ...updateUser }));

    //closes Identification component
    setIdentificationModal(false);
    // opens the contact info window
    setContactInfoModal(true);
  }
  //Sets contact details
  function addContactDetails(
    email: string,
    phoneNumber: number,
    postalAddress: string
  ) {
    let updateUser: any = "";
    updateUser = {
      email: email,
      phoneNumber: phoneNumber,
      postalAddress: postalAddress,
    };
    setUserinfo((userinfo) => ({ ...userinfo, ...updateUser }));
    console.log(userinfo);
    setContactInfoModal(false);
    setDemograpicsModal(true);
  }
  //Sets Demographics
  function addDemographics(
    firstname: string,
    lastname: string,
    age: number,
    married: string,
    highestEducation: string
  ) {
    let updateUser: any;
    updateUser = {
      firstname: firstname,
      lastname: lastname,
      age: age,
      married: married,
      highestEducation: highestEducation,
    };
    setUserinfo((userinfo) => ({ ...userinfo, ...updateUser }));
    setDemograpicsModal(false);
  }
  console.log(userinfo);
  //show/hide certain windows
  const [IdentificationModal, setIdentificationModal] = useState(true);
  const [ContactInfoModal, setContactInfoModal] = useState(false);
  const [DemographicsModal, setDemograpicsModal] = useState(false);
  const [info, setinfo] = useState(false);

  return (
    <Box sx={styles.App}>
      {IdentificationModal && <UsernamePassword addinfo={addUserinfo} />}
      {ContactInfoModal && <ContactInfo addContact={addContactDetails} />}
      {DemographicsModal && (
        <Demographics addDemographics={addDemographics}></Demographics>
      )}
    </Box>
  );
};

const styles = {
  App: {
    backgroundColor: "#282c34",
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "calc(10px + 2vmin)",
    color: "white",
  },
  formContainer: {
    display: "grid",
    gridTemplateColumns: "1fr",
    justifyContent: "space-around",
    gridAutoRows: "minmax(2vh, auto)",
    gap: "1%",
    backgroundColor: "#2b2e4a",
    height: "40vh",
    width: "30vw",
    borderRadius: "5px",
    padding: "2%",
    paddingTop: "4%",
    "@media (max-width:950px)": {
      height: "40vh",
      width: "50vw",
      padding: "1%",
      paddingTop: "5%",
    },
    "@media (max-width:650px)": {
      height: "40vh",
      width: "90vw",
      padding: "1%",
      paddingTop: "5%",
    },
  },
};
