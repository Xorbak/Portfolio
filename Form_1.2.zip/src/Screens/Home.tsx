import Box from "@mui/material/Box";
import { Formik } from "formik";
import React from "react";

export const Home = () => {
  return <Box sx={styles.App}>Home</Box>;
};
const styles = {
  App: {
    textAlign: "center",
    backgroundColor: "#282c34",
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "calc(10px + 2vmin)",
    color: "white",
  },
};
